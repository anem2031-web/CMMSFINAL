' start-silent.vbs
' Runs start.bat completely in the background (no black window at all).
' Put a shortcut to THIS file (not start.bat) inside the Windows Startup folder
' so the scanner service launches automatically and silently every time
' Windows starts - no need to double-click start.bat ever again.

Set fso = CreateObject("Scripting.FileSystemObject")
strScriptDir = fso.GetParentFolderName(WScript.ScriptFullName)

Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """" & strScriptDir & "\start.bat""", 0, False
Set WshShell = Nothing
Set fso = Nothing
